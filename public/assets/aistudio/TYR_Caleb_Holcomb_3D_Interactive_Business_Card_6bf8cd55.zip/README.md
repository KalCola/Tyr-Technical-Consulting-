# TYR Technical Consulting — 3D Omni-Directional Interactive Business Card

**Entity:** CALEB TR HOLCOMB d/b/a TYR (`Tyr's Technical Consultation`)  
**Primary Domain:** [https://tyrprotocol.pro](https://tyrprotocol.pro)  
**Document / Build Version:** v1.2 (AI Studio Inspection, Hardening & Dedicated Publish Archive)

## Included Files in This Archive

1. **`index.html`** — Complete self-contained 3D rotatable business card (with embedded base64 shield logo, inline SVG Patron Triad bind-rune emblem, dual URL/vCard QR code toggle, and `.vcf` generator) mapped as the root entry point for instant preview in Google AI Studio and dedicated static hosting.
2. **`TYR_Caleb_Holcomb_3D_Card_Standalone.html`** — Canonical standalone single-file build from Google Drive.
3. **`index-modular.html`** — Modular HTML5 entry point with externalized stylesheet (`css/card-3d.css`), script (`js/card-3d.js`), and image (`assets/logo-512.jpg`) for isolated code inspection and strict Content-Security-Policy (CSP) hardening in AI Studio.
4. **`css/card-3d.css`** — Extracted 3D card stage, Freyja/Fenrir high-voltage aura borders, aurora oil-slick shaders (`--glint-x`, `--glint-y`, `--oil-angle`), responsive split-plaque grid, and print stylesheet.
5. **`js/card-3d.js`** — Extracted 3D omni-directional drag/touch physics engine, active-face `pointer-events` isolation, Patron Triad tab switcher, dual QR SVG renderer, iframe-resilient link handler, and `.vcf` Blob download trigger.
6. **`assets/logo-512.jpg` & `assets/patron-triad-emblem.svg`** — Extracted visual assets for the Business (Back) and Personal (Front) card faces.
7. **`card.html`** — External-CDN logo variant (`https://tyrprotocol.pro/assets/logo-512.jpg`).
8. **`TYR_Caleb_Holcomb.vcf`** — Companion RFC 6350 / vCard 3.0 contact file (dual email + work phone + GitHub + LinkedIn + OPSEC-redacted region).
9. **`_headers` & `metadata.json` & `package.json`** — Edge security headers (CSP, HSTS, `nosniff`, `Permissions-Policy`) and Google AI Studio project metadata.
