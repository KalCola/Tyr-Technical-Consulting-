(function() {
      "use strict";

      var QR_URL_SVG = '<svg viewBox="0 0 29 29" shape-rendering="crispEdges" role="img" aria-label="QR Code for https://tyrprotocol.pro"><rect width="29" height="29" fill="#ffffff"/><path fill="#000000" d="M2,2h1v1h-1zM3,2h1v1h-1zM4,2h1v1h-1zM5,2h1v1h-1zM6,2h1v1h-1zM7,2h1v1h-1zM8,2h1v1h-1zM11,2h1v1h-1zM12,2h1v1h-1zM15,2h1v1h-1zM16,2h1v1h-1zM17,2h1v1h-1zM20,2h1v1h-1zM21,2h1v1h-1zM22,2h1v1h-1zM23,2h1v1h-1zM24,2h1v1h-1zM25,2h1v1h-1zM26,2h1v1h-1zM2,3h1v1h-1zM8,3h1v1h-1zM10,3h1v1h-1zM12,3h1v1h-1zM13,3h1v1h-1zM16,3h1v1h-1zM17,3h1v1h-1zM18,3h1v1h-1zM20,3h1v1h-1zM26,3h1v1h-1zM2,4h1v1h-1zM4,4h1v1h-1zM5,4h1v1h-1zM6,4h1v1h-1zM8,4h1v1h-1zM11,4h1v1h-1zM12,4h1v1h-1zM13,4h1v1h-1zM17,4h1v1h-1zM18,4h1v1h-1zM20,4h1v1h-1zM22,4h1v1h-1zM23,4h1v1h-1zM24,4h1v1h-1zM26,4h1v1h-1zM2,5h1v1h-1zM4,5h1v1h-1zM5,5h1v1h-1zM6,5h1v1h-1zM8,5h1v1h-1zM13,5h1v1h-1zM16,5h1v1h-1zM17,5h1v1h-1zM20,5h1v1h-1zM22,5h1v1h-1zM23,5h1v1h-1zM24,5h1v1h-1zM26,5h1v1h-1zM2,6h1v1h-1zM4,6h1v1h-1zM5,6h1v1h-1zM6,6h1v1h-1zM8,6h1v1h-1zM10,6h1v1h-1zM12,6h1v1h-1zM13,6h1v1h-1zM15,6h1v1h-1zM16,6h1v1h-1zM17,6h1v1h-1zM20,6h1v1h-1zM22,6h1v1h-1zM23,6h1v1h-1zM24,6h1v1h-1zM26,6h1v1h-1zM2,7h1v1h-1zM8,7h1v1h-1zM14,7h1v1h-1zM15,7h1v1h-1zM16,7h1v1h-1zM17,7h1v1h-1zM18,7h1v1h-1zM20,7h1v1h-1zM26,7h1v1h-1zM2,8h1v1h-1zM3,8h1v1h-1zM4,8h1v1h-1zM5,8h1v1h-1zM6,8h1v1h-1zM7,8h1v1h-1zM8,8h1v1h-1zM10,8h1v1h-1zM12,8h1v1h-1zM14,8h1v1h-1zM16,8h1v1h-1zM18,8h1v1h-1zM20,8h1v1h-1zM21,8h1v1h-1zM22,8h1v1h-1zM23,8h1v1h-1zM24,8h1v1h-1zM25,8h1v1h-1zM26,8h1v1h-1zM11,9h1v1h-1zM12,9h1v1h-1zM13,9h1v1h-1zM14,9h1v1h-1zM15,9h1v1h-1zM18,9h1v1h-1zM2,10h1v1h-1zM4,10h1v1h-1zM6,10h1v1h-1zM8,10h1v1h-1zM14,10h1v1h-1zM15,10h1v1h-1zM16,10h1v1h-1zM17,10h1v1h-1zM18,10h1v1h-1zM22,10h1v1h-1zM25,10h1v1h-1zM5,11h1v1h-1zM7,11h1v1h-1zM18,11h1v1h-1zM20,11h1v1h-1zM26,11h1v1h-1zM3,12h1v1h-1zM4,12h1v1h-1zM5,12h1v1h-1zM8,12h1v1h-1zM15,12h1v1h-1zM18,12h1v1h-1zM22,12h1v1h-1zM24,12h1v1h-1zM25,12h1v1h-1zM26,12h1v1h-1zM3,13h1v1h-1zM5,13h1v1h-1zM6,13h1v1h-1zM10,13h1v1h-1zM12,13h1v1h-1zM13,13h1v1h-1zM14,13h1v1h-1zM15,13h1v1h-1zM17,13h1v1h-1zM18,13h1v1h-1zM25,13h1v1h-1zM3,14h1v1h-1zM4,14h1v1h-1zM5,14h1v1h-1zM7,14h1v1h-1zM8,14h1v1h-1zM11,14h1v1h-1zM12,14h1v1h-1zM14,14h1v1h-1zM15,14h1v1h-1zM19,14h1v1h-1zM20,14h1v1h-1zM21,14h1v1h-1zM23,14h1v1h-1zM25,14h1v1h-1zM26,14h1v1h-1zM5,15h1v1h-1zM7,15h1v1h-1zM10,15h1v1h-1zM13,15h1v1h-1zM14,15h1v1h-1zM15,15h1v1h-1zM16,15h1v1h-1zM18,15h1v1h-1zM20,15h1v1h-1zM23,15h1v1h-1zM26,15h1v1h-1zM2,16h1v1h-1zM4,16h1v1h-1zM5,16h1v1h-1zM6,16h1v1h-1zM8,16h1v1h-1zM11,16h1v1h-1zM13,16h1v1h-1zM14,16h1v1h-1zM16,16h1v1h-1zM20,16h1v1h-1zM21,16h1v1h-1zM24,16h1v1h-1zM25,16h1v1h-1zM26,16h1v1h-1zM3,17h1v1h-1zM4,17h1v1h-1zM7,17h1v1h-1zM12,17h1v1h-1zM14,17h1v1h-1zM15,17h1v1h-1zM18,17h1v1h-1zM19,17h1v1h-1zM20,17h1v1h-1zM22,17h1v1h-1zM25,17h1v1h-1zM2,18h1v1h-1zM4,18h1v1h-1zM6,18h1v1h-1zM7,18h1v1h-1zM8,18h1v1h-1zM11,18h1v1h-1zM13,18h1v1h-1zM15,18h1v1h-1zM17,18h1v1h-1zM18,18h1v1h-1zM19,18h1v1h-1zM20,18h1v1h-1zM21,18h1v1h-1zM22,18h1v1h-1zM23,18h1v1h-1zM10,19h1v1h-1zM11,19h1v1h-1zM12,19h1v1h-1zM13,19h1v1h-1zM15,19h1v1h-1zM16,19h1v1h-1zM17,19h1v1h-1zM18,19h1v1h-1zM22,19h1v1h-1zM23,19h1v1h-1zM25,19h1v1h-1zM26,19h1v1h-1zM2,20h1v1h-1zM3,20h1v1h-1zM4,20h1v1h-1zM5,20h1v1h-1zM6,20h1v1h-1zM7,20h1v1h-1zM8,20h1v1h-1zM15,20h1v1h-1zM16,20h1v1h-1zM17,20h1v1h-1zM18,20h1v1h-1zM20,20h1v1h-1zM22,20h1v1h-1zM23,20h1v1h-1zM25,20h1v1h-1zM26,20h1v1h-1zM2,21h1v1h-1zM8,21h1v1h-1zM11,21h1v1h-1zM13,21h1v1h-1zM15,21h1v1h-1zM18,21h1v1h-1zM22,21h1v1h-1zM23,21h1v1h-1zM26,21h1v1h-1zM2,22h1v1h-1zM4,22h1v1h-1zM5,22h1v1h-1zM6,22h1v1h-1zM8,22h1v1h-1zM10,22h1v1h-1zM14,22h1v1h-1zM15,22h1v1h-1zM18,22h1v1h-1zM19,22h1v1h-1zM20,22h1v1h-1zM21,22h1v1h-1zM22,22h1v1h-1zM23,22h1v1h-1zM25,22h1v1h-1zM26,22h1v1h-1zM2,23h1v1h-1zM4,23h1v1h-1zM5,23h1v1h-1zM6,23h1v1h-1zM8,23h1v1h-1zM11,23h1v1h-1zM12,23h1v1h-1zM13,23h1v1h-1zM14,23h1v1h-1zM17,23h1v1h-1zM18,23h1v1h-1zM21,23h1v1h-1zM22,23h1v1h-1zM23,23h1v1h-1zM24,23h1v1h-1zM2,24h1v1h-1zM4,24h1v1h-1zM5,24h1v1h-1zM6,24h1v1h-1zM8,24h1v1h-1zM10,24h1v1h-1zM11,24h1v1h-1zM12,24h1v1h-1zM13,24h1v1h-1zM14,24h1v1h-1zM15,24h1v1h-1zM18,24h1v1h-1zM19,24h1v1h-1zM22,24h1v1h-1zM26,24h1v1h-1zM2,25h1v1h-1zM8,25h1v1h-1zM12,25h1v1h-1zM14,25h1v1h-1zM15,25h1v1h-1zM16,25h1v1h-1zM18,25h1v1h-1zM19,25h1v1h-1zM22,25h1v1h-1zM23,25h1v1h-1zM25,25h1v1h-1zM2,26h1v1h-1zM3,26h1v1h-1zM4,26h1v1h-1zM5,26h1v1h-1zM6,26h1v1h-1zM7,26h1v1h-1zM8,26h1v1h-1zM10,26h1v1h-1zM12,26h1v1h-1zM13,26h1v1h-1zM14,26h1v1h-1zM16,26h1v1h-1zM17,26h1v1h-1zM18,26h1v1h-1zM20,26h1v1h-1zM21,26h1v1h-1zM25,26h1v1h-1zM26,26h1v1h-1z"/></svg>';
      var QR_VCARD_SVG = '<svg viewBox="0 0 53 53" shape-rendering="crispEdges" role="img" aria-label="QR Code for Dual-Email vCard Contact"><rect width="53" height="53" fill="#ffffff"/><path fill="#000000" d="M2,2h1v1h-1zM3,2h1v1h-1zM4,2h1v1h-1zM5,2h1v1h-1zM6,2h1v1h-1zM7,2h1v1h-1zM8,2h1v1h-1zM11,2h1v1h-1zM13,2h1v1h-1zM17,2h1v1h-1zM18,2h1v1h-1zM19,2h1v1h-1zM21,2h1v1h-1zM22,2h1v1h-1zM23,2h1v1h-1zM24,2h1v1h-1zM27,2h1v1h-1zM28,2h1v1h-1zM31,2h1v1h-1zM32,2h1v1h-1zM33,2h1v1h-1zM34,2h1v1h-1zM35,2h1v1h-1zM36,2h1v1h-1zM39,2h1v1h-1zM42,2h1v1h-1zM44,2h1v1h-1zM45,2h1v1h-1zM46,2h1v1h-1zM47,2h1v1h-1zM48,2h1v1h-1zM49,2h1v1h-1zM50,2h1v1h-1zM2,3h1v1h-1zM8,3h1v1h-1zM11,3h1v1h-1zM13,3h1v1h-1zM14,3h1v1h-1zM16,3h1v1h-1zM18,3h1v1h-1zM20,3h1v1h-1zM21,3h1v1h-1zM22,3h1v1h-1zM23,3h1v1h-1zM25,3h1v1h-1zM26,3h1v1h-1zM27,3h1v1h-1zM28,3h1v1h-1zM29,3h1v1h-1zM32,3h1v1h-1zM33,3h1v1h-1zM34,3h1v1h-1zM35,3h1v1h-1zM37,3h1v1h-1zM40,3h1v1h-1zM41,3h1v1h-1zM42,3h1v1h-1zM44,3h1v1h-1zM50,3h1v1h-1zM2,4h1v1h-1zM4,4h1v1h-1zM5,4h1v1h-1zM6,4h1v1h-1zM8,4h1v1h-1zM10,4h1v1h-1zM11,4h1v1h-1zM12,4h1v1h-1zM17,4h1v1h-1zM24,4h1v1h-1zM26,4h1v1h-1zM29,4h1v1h-1zM31,4h1v1h-1zM32,4h1v1h-1zM33,4h1v1h-1zM34,4h1v1h-1zM36,4h1v1h-1zM41,4h1v1h-1zM42,4h1v1h-1zM44,4h1v1h-1zM46,4h1v1h-1zM47,4h1v1h-1zM48,4h1v1h-1zM50,4h1v1h-1zM2,5h1v1h-1zM4,5h1v1h-1zM5,5h1v1h-1zM6,5h1v1h-1zM8,5h1v1h-1zM12,5h1v1h-1zM13,5h1v1h-1zM14,5h1v1h-1zM16,5h1v1h-1zM20,5h1v1h-1zM29,5h1v1h-1zM31,5h1v1h-1zM35,5h1v1h-1zM36,5h1v1h-1zM39,5h1v1h-1zM41,5h1v1h-1zM44,5h1v1h-1zM46,5h1v1h-1zM47,5h1v1h-1zM48,5h1v1h-1zM50,5h1v1h-1zM2,6h1v1h-1zM4,6h1v1h-1zM5,6h1v1h-1zM6,6h1v1h-1zM8,6h1v1h-1zM12,6h1v1h-1zM16,6h1v1h-1zM18,6h1v1h-1zM20,6h1v1h-1zM22,6h1v1h-1zM24,6h1v1h-1zM25,6h1v1h-1zM26,6h1v1h-1zM27,6h1v1h-1zM28,6h1v1h-1zM29,6h1v1h-1zM30,6h1v1h-1zM31,6h1v1h-1zM32,6h1v1h-1zM36,6h1v1h-1zM37,6h1v1h-1zM38,6h1v1h-1zM39,6h1v1h-1zM44,6h1v1h-1zM46,6h1v1h-1zM47,6h1v1h-1zM48,6h1v1h-1zM50,6h1v1h-1zM2,7h1v1h-1zM8,7h1v1h-1zM11,7h1v1h-1zM14,7h1v1h-1zM15,7h1v1h-1zM24,7h1v1h-1zM28,7h1v1h-1zM33,7h1v1h-1zM34,7h1v1h-1zM36,7h1v1h-1zM38,7h1v1h-1zM39,7h1v1h-1zM40,7h1v1h-1zM44,7h1v1h-1zM50,7h1v1h-1zM2,8h1v1h-1zM3,8h1v1h-1zM4,8h1v1h-1zM5,8h1v1h-1zM6,8h1v1h-1zM7,8h1v1h-1zM8,8h1v1h-1zM10,8h1v1h-1zM12,8h1v1h-1zM14,8h1v1h-1zM16,8h1v1h-1zM18,8h1v1h-1zM20,8h1v1h-1zM22,8h1v1h-1zM24,8h1v1h-1zM26,8h1v1h-1zM28,8h1v1h-1zM30,8h1v1h-1zM32,8h1v1h-1zM34,8h1v1h-1zM36,8h1v1h-1zM38,8h1v1h-1zM40,8h1v1h-1zM42,8h1v1h-1zM44,8h1v1h-1zM45,8h1v1h-1zM46,8h1v1h-1zM47,8h1v1h-1zM48,8h1v1h-1zM49,8h1v1h-1zM50,8h1v1h-1zM10,9h1v1h-1zM11,9h1v1h-1zM13,9h1v1h-1zM14,9h1v1h-1zM16,9h1v1h-1zM17,9h1v1h-1zM19,9h1v1h-1zM21,9h1v1h-1zM23,9h1v1h-1zM24,9h1v1h-1zM28,9h1v1h-1zM30,9h1v1h-1zM31,9h1v1h-1zM34,9h1v1h-1zM36,9h1v1h-1zM41,9h1v1h-1zM2,10h1v1h-1zM3,10h1v1h-1zM4,10h1v1h-1zM6,10h1v1h-1zM7,10h1v1h-1zM8,10h1v1h-1zM9,10h1v1h-1zM10,10h1v1h-1zM11,10h1v1h-1zM12,10h1v1h-1zM14,10h1v1h-1zM15,10h1v1h-1zM16,10h1v1h-1zM19,10h1v1h-1zM20,10h1v1h-1zM21,10h1v1h-1zM23,10h1v1h-1zM24,10h1v1h-1zM25,10h1v1h-1zM26,10h1v1h-1zM27,10h1v1h-1zM28,10h1v1h-1zM29,10h1v1h-1zM30,10h1v1h-1zM33,10h1v1h-1zM34,10h1v1h-1zM36,10h1v1h-1zM37,10h1v1h-1zM38,10h1v1h-1zM39,10h1v1h-1zM43,10h1v1h-1zM44,10h1v1h-1zM48,10h1v1h-1zM2,11h1v1h-1zM3,11h1v1h-1zM4,11h1v1h-1zM5,11h1v1h-1zM7,11h1v1h-1zM10,11h1v1h-1zM12,11h1v1h-1zM13,11h1v1h-1zM14,11h1v1h-1zM15,11h1v1h-1zM16,11h1v1h-1zM20,11h1v1h-1zM21,11h1v1h-1zM26,11h1v1h-1zM27,11h1v1h-1zM29,11h1v1h-1zM33,11h1v1h-1zM35,11h1v1h-1zM46,11h1v1h-1zM47,11h1v1h-1zM48,11h1v1h-1zM49,11h1v1h-1zM2,12h1v1h-1zM3,12h1v1h-1zM5,12h1v1h-1zM7,12h1v1h-1zM8,12h1v1h-1zM9,12h1v1h-1zM10,12h1v1h-1zM13,12h1v1h-1zM14,12h1v1h-1zM16,12h1v1h-1zM18,12h1v1h-1zM20,12h1v1h-1zM21,12h1v1h-1zM23,12h1v1h-1zM24,12h1v1h-1zM26,12h1v1h-1zM27,12h1v1h-1zM30,12h1v1h-1zM31,12h1v1h-1zM33,12h1v1h-1zM34,12h1v1h-1zM35,12h1v1h-1zM37,12h1v1h-1zM38,12h1v1h-1zM42,12h1v1h-1zM45,12h1v1h-1zM47,12h1v1h-1zM48,12h1v1h-1zM49,12h1v1h-1zM50,12h1v1h-1zM2,13h1v1h-1zM3,13h1v1h-1zM4,13h1v1h-1zM6,13h1v1h-1zM12,13h1v1h-1zM14,13h1v1h-1zM21,13h1v1h-1zM22,13h1v1h-1zM25,13h1v1h-1zM28,13h1v1h-1zM30,13h1v1h-1zM31,13h1v1h-1zM32,13h1v1h-1zM34,13h1v1h-1zM35,13h1v1h-1zM36,13h1v1h-1zM37,13h1v1h-1zM38,13h1v1h-1zM40,13h1v1h-1zM41,13h1v1h-1zM3,14h1v1h-1zM4,14h1v1h-1zM5,14h1v1h-1zM8,14h1v1h-1zM9,14h1v1h-1zM10,14h1v1h-1zM12,14h1v1h-1zM16,14h1v1h-1zM18,14h1v1h-1zM20,14h1v1h-1zM22,14h1v1h-1zM24,14h1v1h-1zM26,14h1v1h-1zM27,14h1v1h-1zM30,14h1v1h-1zM31,14h1v1h-1zM32,14h1v1h-1zM34,14h1v1h-1zM35,14h1v1h-1zM37,14h1v1h-1zM38,14h1v1h-1zM41,14h1v1h-1zM45,14h1v1h-1zM46,14h1v1h-1zM48,14h1v1h-1zM2,15h1v1h-1zM3,15h1v1h-1zM9,15h1v1h-1zM11,15h1v1h-1zM13,15h1v1h-1zM18,15h1v1h-1zM22,15h1v1h-1zM23,15h1v1h-1zM26,15h1v1h-1zM27,15h1v1h-1zM29,15h1v1h-1zM30,15h1v1h-1zM34,15h1v1h-1zM38,15h1v1h-1zM39,15h1v1h-1zM41,15h1v1h-1zM45,15h1v1h-1zM46,15h1v1h-1zM48,15h1v1h-1zM49,15h1v1h-1zM2,16h1v1h-1zM3,16h1v1h-1zM6,16h1v1h-1zM8,16h1v1h-1zM9,16h1v1h-1zM11,16h1v1h-1zM15,16h1v1h-1zM26,16h1v1h-1zM28,16h1v1h-1zM29,16h1v1h-1zM30,16h1v1h-1zM31,16h1v1h-1zM32,16h1v1h-1zM33,16h1v1h-1zM34,16h1v1h-1zM36,16h1v1h-1zM37,16h1v1h-1zM39,16h1v1h-1zM44,16h1v1h-1zM48,16h1v1h-1zM49,16h1v1h-1zM50,16h1v1h-1zM3,17h1v1h-1zM5,17h1v1h-1zM6,17h1v1h-1zM10,17h1v1h-1zM11,17h1v1h-1zM12,17h1v1h-1zM14,17h1v1h-1zM16,17h1v1h-1zM18,17h1v1h-1zM22,17h1v1h-1zM25,17h1v1h-1zM27,17h1v1h-1zM30,17h1v1h-1zM31,17h1v1h-1zM34,17h1v1h-1zM35,17h1v1h-1zM36,17h1v1h-1zM40,17h1v1h-1zM41,17h1v1h-1zM42,17h1v1h-1zM44,17h1v1h-1zM45,17h1v1h-1zM46,17h1v1h-1zM47,17h1v1h-1zM50,17h1v1h-1zM2,18h1v1h-1zM3,18h1v1h-1zM4,18h1v1h-1zM5,18h1v1h-1zM6,18h1v1h-1zM7,18h1v1h-1zM8,18h1v1h-1zM9,18h1v1h-1zM10,18h1v1h-1zM14,18h1v1h-1zM15,18h1v1h-1zM16,18h1v1h-1zM17,18h1v1h-1zM19,18h1v1h-1zM20,18h1v1h-1zM22,18h1v1h-1zM24,18h1v1h-1zM25,18h1v1h-1zM26,18h1v1h-1zM29,18h1v1h-1zM30,18h1v1h-1zM32,18h1v1h-1zM33,18h1v1h-1zM34,18h1v1h-1zM37,18h1v1h-1zM38,18h1v1h-1zM39,18h1v1h-1zM40,18h1v1h-1zM42,18h1v1h-1zM44,18h1v1h-1zM45,18h1v1h-1zM46,18h1v1h-1zM47,18h1v1h-1zM49,18h1v1h-1zM50,18h1v1h-1zM3,19h1v1h-1zM4,19h1v1h-1zM5,19h1v1h-1zM6,19h1v1h-1zM7,19h1v1h-1zM11,19h1v1h-1zM12,19h1v1h-1zM13,19h1v1h-1zM15,19h1v1h-1zM16,19h1v1h-1zM20,19h1v1h-1zM24,19h1v1h-1zM25,19h1v1h-1zM26,19h1v1h-1zM27,19h1v1h-1zM29,19h1v1h-1zM30,19h1v1h-1zM34,19h1v1h-1zM37,19h1v1h-1zM38,19h1v1h-1zM46,19h1v1h-1zM48,19h1v1h-1zM49,19h1v1h-1zM2,20h1v1h-1zM3,20h1v1h-1zM8,20h1v1h-1zM11,20h1v1h-1zM12,20h1v1h-1zM14,20h1v1h-1zM15,20h1v1h-1zM17,20h1v1h-1zM19,20h1v1h-1zM23,20h1v1h-1zM24,20h1v1h-1zM25,20h1v1h-1zM26,20h1v1h-1zM27,20h1v1h-1zM29,20h1v1h-1zM31,20h1v1h-1zM33,20h1v1h-1zM41,20h1v1h-1zM46,20h1v1h-1zM49,20h1v1h-1zM50,20h1v1h-1zM2,21h1v1h-1zM3,21h1v1h-1zM4,21h1v1h-1zM10,21h1v1h-1zM11,21h1v1h-1zM12,21h1v1h-1zM13,21h1v1h-1zM14,21h1v1h-1zM15,21h1v1h-1zM16,21h1v1h-1zM18,21h1v1h-1zM19,21h1v1h-1zM20,21h1v1h-1zM21,21h1v1h-1zM26,21h1v1h-1zM27,21h1v1h-1zM28,21h1v1h-1zM30,21h1v1h-1zM31,21h1v1h-1zM33,21h1v1h-1zM35,21h1v1h-1zM37,21h1v1h-1zM38,21h1v1h-1zM39,21h1v1h-1zM41,21h1v1h-1zM45,21h1v1h-1zM47,21h1v1h-1zM2,22h1v1h-1zM6,22h1v1h-1zM7,22h1v1h-1zM8,22h1v1h-1zM9,22h1v1h-1zM10,22h1v1h-1zM12,22h1v1h-1zM13,22h1v1h-1zM15,22h1v1h-1zM17,22h1v1h-1zM18,22h1v1h-1zM19,22h1v1h-1zM21,22h1v1h-1zM22,22h1v1h-1zM24,22h1v1h-1zM26,22h1v1h-1zM30,22h1v1h-1zM33,22h1v1h-1zM34,22h1v1h-1zM35,22h1v1h-1zM37,22h1v1h-1zM38,22h1v1h-1zM40,22h1v1h-1zM41,22h1v1h-1zM43,22h1v1h-1zM44,22h1v1h-1zM46,22h1v1h-1zM47,22h1v1h-1zM50,22h1v1h-1zM2,23h1v1h-1zM6,23h1v1h-1zM7,23h1v1h-1zM9,23h1v1h-1zM11,23h1v1h-1zM13,23h1v1h-1zM15,23h1v1h-1zM17,23h1v1h-1zM19,23h1v1h-1zM21,23h1v1h-1zM25,23h1v1h-1zM31,23h1v1h-1zM33,23h1v1h-1zM34,23h1v1h-1zM38,23h1v1h-1zM39,23h1v1h-1zM41,23h1v1h-1zM45,23h1v1h-1zM47,23h1v1h-1zM48,23h1v1h-1zM49,23h1v1h-1zM2,24h1v1h-1zM4,24h1v1h-1zM5,24h1v1h-1zM6,24h1v1h-1zM7,24h1v1h-1zM8,24h1v1h-1zM9,24h1v1h-1zM10,24h1v1h-1zM12,24h1v1h-1zM13,24h1v1h-1zM14,24h1v1h-1zM15,24h1v1h-1zM17,24h1v1h-1zM18,24h1v1h-1zM20,24h1v1h-1zM21,24h1v1h-1zM22,24h1v1h-1zM24,24h1v1h-1zM25,24h1v1h-1zM26,24h1v1h-1zM27,24h1v1h-1zM28,24h1v1h-1zM30,24h1v1h-1zM32,24h1v1h-1zM34,24h1v1h-1zM38,24h1v1h-1zM40,24h1v1h-1zM42,24h1v1h-1zM43,24h1v1h-1zM44,24h1v1h-1zM45,24h1v1h-1zM46,24h1v1h-1zM47,24h1v1h-1zM49,24h1v1h-1zM50,24h1v1h-1zM2,25h1v1h-1zM5,25h1v1h-1zM6,25h1v1h-1zM10,25h1v1h-1zM11,25h1v1h-1zM14,25h1v1h-1zM15,25h1v1h-1zM17,25h1v1h-1zM19,25h1v1h-1zM20,25h1v1h-1zM21,25h1v1h-1zM23,25h1v1h-1zM24,25h1v1h-1zM28,25h1v1h-1zM29,25h1v1h-1zM30,25h1v1h-1zM31,25h1v1h-1zM33,25h1v1h-1zM34,25h1v1h-1zM35,25h1v1h-1zM36,25h1v1h-1zM37,25h1v1h-1zM39,25h1v1h-1zM42,25h1v1h-1zM46,25h1v1h-1zM5,26h1v1h-1zM6,26h1v1h-1zM8,26h1v1h-1zM10,26h1v1h-1zM12,26h1v1h-1zM13,26h1v1h-1zM16,26h1v1h-1zM19,26h1v1h-1zM20,26h1v1h-1zM21,26h1v1h-1zM22,26h1v1h-1zM24,26h1v1h-1zM26,26h1v1h-1zM28,26h1v1h-1zM30,26h1v1h-1zM34,26h1v1h-1zM36,26h1v1h-1zM38,26h1v1h-1zM39,26h1v1h-1zM40,26h1v1h-1zM41,26h1v1h-1zM42,26h1v1h-1zM44,26h1v1h-1zM46,26h1v1h-1zM48,26h1v1h-1zM49,26h1v1h-1zM50,26h1v1h-1zM3,27h1v1h-1zM4,27h1v1h-1zM5,27h1v1h-1zM6,27h1v1h-1zM10,27h1v1h-1zM12,27h1v1h-1zM13,27h1v1h-1zM15,27h1v1h-1zM16,27h1v1h-1zM19,27h1v1h-1zM23,27h1v1h-1zM24,27h1v1h-1zM28,27h1v1h-1zM29,27h1v1h-1zM34,27h1v1h-1zM42,27h1v1h-1zM46,27h1v1h-1zM47,27h1v1h-1zM48,27h1v1h-1zM49,27h1v1h-1zM4,28h1v1h-1zM5,28h1v1h-1zM6,28h1v1h-1zM7,28h1v1h-1zM8,28h1v1h-1zM9,28h1v1h-1zM10,28h1v1h-1zM11,28h1v1h-1zM13,28h1v1h-1zM16,28h1v1h-1zM20,28h1v1h-1zM21,28h1v1h-1zM24,28h1v1h-1zM25,28h1v1h-1zM26,28h1v1h-1zM27,28h1v1h-1zM28,28h1v1h-1zM29,28h1v1h-1zM33,28h1v1h-1zM35,28h1v1h-1zM37,28h1v1h-1zM41,28h1v1h-1zM42,28h1v1h-1zM43,28h1v1h-1zM44,28h1v1h-1zM45,28h1v1h-1zM46,28h1v1h-1zM49,28h1v1h-1zM50,28h1v1h-1zM3,29h1v1h-1zM4,29h1v1h-1zM6,29h1v1h-1zM7,29h1v1h-1zM9,29h1v1h-1zM10,29h1v1h-1zM11,29h1v1h-1zM13,29h1v1h-1zM14,29h1v1h-1zM17,29h1v1h-1zM22,29h1v1h-1zM23,29h1v1h-1zM27,29h1v1h-1zM30,29h1v1h-1zM31,29h1v1h-1zM32,29h1v1h-1zM35,29h1v1h-1zM37,29h1v1h-1zM38,29h1v1h-1zM39,29h1v1h-1zM40,29h1v1h-1zM4,30h1v1h-1zM5,30h1v1h-1zM7,30h1v1h-1zM8,30h1v1h-1zM9,30h1v1h-1zM10,30h1v1h-1zM13,30h1v1h-1zM16,30h1v1h-1zM18,30h1v1h-1zM20,30h1v1h-1zM22,30h1v1h-1zM24,30h1v1h-1zM25,30h1v1h-1zM26,30h1v1h-1zM27,30h1v1h-1zM28,30h1v1h-1zM30,30h1v1h-1zM33,30h1v1h-1zM34,30h1v1h-1zM35,30h1v1h-1zM36,30h1v1h-1zM37,30h1v1h-1zM38,30h1v1h-1zM42,30h1v1h-1zM44,30h1v1h-1zM47,30h1v1h-1zM48,30h1v1h-1zM49,30h1v1h-1zM3,31h1v1h-1zM7,31h1v1h-1zM9,31h1v1h-1zM13,31h1v1h-1zM18,31h1v1h-1zM22,31h1v1h-1zM23,31h1v1h-1zM24,31h1v1h-1zM30,31h1v1h-1zM34,31h1v1h-1zM37,31h1v1h-1zM41,31h1v1h-1zM42,31h1v1h-1zM47,31h1v1h-1zM48,31h1v1h-1zM49,31h1v1h-1zM2,32h1v1h-1zM3,32h1v1h-1zM4,32h1v1h-1zM5,32h1v1h-1zM7,32h1v1h-1zM8,32h1v1h-1zM10,32h1v1h-1zM11,32h1v1h-1zM13,32h1v1h-1zM15,32h1v1h-1zM20,32h1v1h-1zM28,32h1v1h-1zM31,32h1v1h-1zM32,32h1v1h-1zM33,32h1v1h-1zM37,32h1v1h-1zM40,32h1v1h-1zM42,32h1v1h-1zM43,32h1v1h-1zM44,32h1v1h-1zM48,32h1v1h-1zM49,32h1v1h-1zM50,32h1v1h-1zM2,33h1v1h-1zM4,33h1v1h-1zM5,33h1v1h-1zM7,33h1v1h-1zM10,33h1v1h-1zM11,33h1v1h-1zM12,33h1v1h-1zM13,33h1v1h-1zM15,33h1v1h-1zM16,33h1v1h-1zM18,33h1v1h-1zM19,33h1v1h-1zM22,33h1v1h-1zM25,33h1v1h-1zM26,33h1v1h-1zM28,33h1v1h-1zM29,33h1v1h-1zM30,33h1v1h-1zM32,33h1v1h-1zM33,33h1v1h-1zM34,33h1v1h-1zM37,33h1v1h-1zM38,33h1v1h-1zM39,33h1v1h-1zM40,33h1v1h-1zM41,33h1v1h-1zM42,33h1v1h-1zM43,33h1v1h-1zM44,33h1v1h-1zM45,33h1v1h-1zM46,33h1v1h-1zM49,33h1v1h-1zM50,33h1v1h-1zM4,34h1v1h-1zM6,34h1v1h-1zM8,34h1v1h-1zM9,34h1v1h-1zM10,34h1v1h-1zM11,34h1v1h-1zM14,34h1v1h-1zM15,34h1v1h-1zM16,34h1v1h-1zM17,34h1v1h-1zM19,34h1v1h-1zM20,34h1v1h-1zM22,34h1v1h-1zM23,34h1v1h-1zM25,34h1v1h-1zM27,34h1v1h-1zM28,34h1v1h-1zM29,34h1v1h-1zM30,34h1v1h-1zM31,34h1v1h-1zM34,34h1v1h-1zM36,34h1v1h-1zM37,34h1v1h-1zM38,34h1v1h-1zM39,34h1v1h-1zM40,34h1v1h-1zM44,34h1v1h-1zM46,34h1v1h-1zM48,34h1v1h-1zM50,34h1v1h-1zM2,35h1v1h-1zM4,35h1v1h-1zM10,35h1v1h-1zM11,35h1v1h-1zM12,35h1v1h-1zM16,35h1v1h-1zM20,35h1v1h-1zM25,35h1v1h-1zM30,35h1v1h-1zM33,35h1v1h-1zM34,35h1v1h-1zM38,35h1v1h-1zM42,35h1v1h-1zM43,35h1v1h-1zM44,35h1v1h-1zM49,35h1v1h-1zM3,36h1v1h-1zM4,36h1v1h-1zM5,36h1v1h-1zM8,36h1v1h-1zM9,36h1v1h-1zM14,36h1v1h-1zM15,36h1v1h-1zM18,36h1v1h-1zM19,36h1v1h-1zM21,36h1v1h-1zM26,36h1v1h-1zM27,36h1v1h-1zM28,36h1v1h-1zM29,36h1v1h-1zM31,36h1v1h-1zM35,36h1v1h-1zM37,36h1v1h-1zM41,36h1v1h-1zM43,36h1v1h-1zM44,36h1v1h-1zM49,36h1v1h-1zM50,36h1v1h-1zM2,37h1v1h-1zM5,37h1v1h-1zM6,37h1v1h-1zM7,37h1v1h-1zM9,37h1v1h-1zM11,37h1v1h-1zM15,37h1v1h-1zM16,37h1v1h-1zM17,37h1v1h-1zM19,37h1v1h-1zM20,37h1v1h-1zM25,37h1v1h-1zM27,37h1v1h-1zM29,37h1v1h-1zM30,37h1v1h-1zM33,37h1v1h-1zM36,37h1v1h-1zM37,37h1v1h-1zM38,37h1v1h-1zM40,37h1v1h-1zM45,37h1v1h-1zM3,38h1v1h-1zM7,38h1v1h-1zM8,38h1v1h-1zM11,38h1v1h-1zM12,38h1v1h-1zM13,38h1v1h-1zM14,38h1v1h-1zM15,38h1v1h-1zM17,38h1v1h-1zM18,38h1v1h-1zM19,38h1v1h-1zM21,38h1v1h-1zM22,38h1v1h-1zM24,38h1v1h-1zM25,38h1v1h-1zM27,38h1v1h-1zM28,38h1v1h-1zM30,38h1v1h-1zM32,38h1v1h-1zM33,38h1v1h-1zM34,38h1v1h-1zM36,38h1v1h-1zM37,38h1v1h-1zM38,38h1v1h-1zM42,38h1v1h-1zM44,38h1v1h-1zM45,38h1v1h-1zM48,38h1v1h-1zM49,38h1v1h-1zM50,38h1v1h-1zM2,39h1v1h-1zM4,39h1v1h-1zM10,39h1v1h-1zM11,39h1v1h-1zM13,39h1v1h-1zM15,39h1v1h-1zM17,39h1v1h-1zM19,39h1v1h-1zM21,39h1v1h-1zM23,39h1v1h-1zM24,39h1v1h-1zM25,39h1v1h-1zM28,39h1v1h-1zM29,39h1v1h-1zM30,39h1v1h-1zM33,39h1v1h-1zM34,39h1v1h-1zM38,39h1v1h-1zM39,39h1v1h-1zM41,39h1v1h-1zM42,39h1v1h-1zM44,39h1v1h-1zM45,39h1v1h-1zM48,39h1v1h-1zM49,39h1v1h-1zM3,40h1v1h-1zM7,40h1v1h-1zM8,40h1v1h-1zM11,40h1v1h-1zM13,40h1v1h-1zM14,40h1v1h-1zM16,40h1v1h-1zM17,40h1v1h-1zM18,40h1v1h-1zM19,40h1v1h-1zM20,40h1v1h-1zM21,40h1v1h-1zM22,40h1v1h-1zM26,40h1v1h-1zM28,40h1v1h-1zM32,40h1v1h-1zM37,40h1v1h-1zM39,40h1v1h-1zM41,40h1v1h-1zM42,40h1v1h-1zM43,40h1v1h-1zM44,40h1v1h-1zM45,40h1v1h-1zM46,40h1v1h-1zM47,40h1v1h-1zM49,40h1v1h-1zM50,40h1v1h-1zM3,41h1v1h-1zM4,41h1v1h-1zM5,41h1v1h-1zM9,41h1v1h-1zM10,41h1v1h-1zM13,41h1v1h-1zM15,41h1v1h-1zM17,41h1v1h-1zM19,41h1v1h-1zM21,41h1v1h-1zM23,41h1v1h-1zM28,41h1v1h-1zM29,41h1v1h-1zM30,41h1v1h-1zM34,41h1v1h-1zM37,41h1v1h-1zM38,41h1v1h-1zM40,41h1v1h-1zM41,41h1v1h-1zM42,41h1v1h-1zM43,41h1v1h-1zM44,41h1v1h-1zM49,41h1v1h-1zM2,42h1v1h-1zM3,42h1v1h-1zM4,42h1v1h-1zM8,42h1v1h-1zM9,42h1v1h-1zM11,42h1v1h-1zM14,42h1v1h-1zM15,42h1v1h-1zM16,42h1v1h-1zM17,42h1v1h-1zM19,42h1v1h-1zM20,42h1v1h-1zM21,42h1v1h-1zM22,42h1v1h-1zM24,42h1v1h-1zM25,42h1v1h-1zM26,42h1v1h-1zM27,42h1v1h-1zM28,42h1v1h-1zM29,42h1v1h-1zM30,42h1v1h-1zM32,42h1v1h-1zM34,42h1v1h-1zM36,42h1v1h-1zM37,42h1v1h-1zM38,42h1v1h-1zM40,42h1v1h-1zM42,42h1v1h-1zM43,42h1v1h-1zM44,42h1v1h-1zM45,42h1v1h-1zM46,42h1v1h-1zM48,42h1v1h-1zM49,42h1v1h-1zM50,42h1v1h-1zM10,43h1v1h-1zM12,43h1v1h-1zM13,43h1v1h-1zM16,43h1v1h-1zM20,43h1v1h-1zM23,43h1v1h-1zM24,43h1v1h-1zM28,43h1v1h-1zM30,43h1v1h-1zM34,43h1v1h-1zM38,43h1v1h-1zM39,43h1v1h-1zM42,43h1v1h-1zM46,43h1v1h-1zM47,43h1v1h-1zM49,43h1v1h-1zM2,44h1v1h-1zM3,44h1v1h-1zM4,44h1v1h-1zM5,44h1v1h-1zM6,44h1v1h-1zM7,44h1v1h-1zM8,44h1v1h-1zM10,44h1v1h-1zM11,44h1v1h-1zM12,44h1v1h-1zM13,44h1v1h-1zM16,44h1v1h-1zM20,44h1v1h-1zM21,44h1v1h-1zM23,44h1v1h-1zM24,44h1v1h-1zM26,44h1v1h-1zM28,44h1v1h-1zM30,44h1v1h-1zM34,44h1v1h-1zM35,44h1v1h-1zM38,44h1v1h-1zM42,44h1v1h-1zM44,44h1v1h-1zM46,44h1v1h-1zM47,44h1v1h-1zM49,44h1v1h-1zM50,44h1v1h-1zM2,45h1v1h-1zM8,45h1v1h-1zM10,45h1v1h-1zM14,45h1v1h-1zM17,45h1v1h-1zM21,45h1v1h-1zM22,45h1v1h-1zM23,45h1v1h-1zM24,45h1v1h-1zM28,45h1v1h-1zM30,45h1v1h-1zM33,45h1v1h-1zM37,45h1v1h-1zM38,45h1v1h-1zM39,45h1v1h-1zM40,45h1v1h-1zM41,45h1v1h-1zM42,45h1v1h-1zM46,45h1v1h-1zM49,45h1v1h-1zM50,45h1v1h-1zM2,46h1v1h-1zM4,46h1v1h-1zM5,46h1v1h-1zM6,46h1v1h-1zM8,46h1v1h-1zM10,46h1v1h-1zM11,46h1v1h-1zM14,46h1v1h-1zM16,46h1v1h-1zM18,46h1v1h-1zM20,46h1v1h-1zM22,46h1v1h-1zM24,46h1v1h-1zM25,46h1v1h-1zM26,46h1v1h-1zM27,46h1v1h-1zM28,46h1v1h-1zM30,46h1v1h-1zM31,46h1v1h-1zM32,46h1v1h-1zM34,46h1v1h-1zM35,46h1v1h-1zM36,46h1v1h-1zM37,46h1v1h-1zM38,46h1v1h-1zM41,46h1v1h-1zM42,46h1v1h-1zM43,46h1v1h-1zM44,46h1v1h-1zM45,46h1v1h-1zM46,46h1v1h-1zM48,46h1v1h-1zM2,47h1v1h-1zM4,47h1v1h-1zM5,47h1v1h-1zM6,47h1v1h-1zM8,47h1v1h-1zM14,47h1v1h-1zM18,47h1v1h-1zM22,47h1v1h-1zM26,47h1v1h-1zM28,47h1v1h-1zM29,47h1v1h-1zM33,47h1v1h-1zM34,47h1v1h-1zM37,47h1v1h-1zM41,47h1v1h-1zM42,47h1v1h-1zM43,47h1v1h-1zM48,47h1v1h-1zM49,47h1v1h-1zM50,47h1v1h-1zM2,48h1v1h-1zM4,48h1v1h-1zM5,48h1v1h-1zM6,48h1v1h-1zM8,48h1v1h-1zM10,48h1v1h-1zM16,48h1v1h-1zM23,48h1v1h-1zM26,48h1v1h-1zM29,48h1v1h-1zM32,48h1v1h-1zM34,48h1v1h-1zM40,48h1v1h-1zM41,48h1v1h-1zM42,48h1v1h-1zM43,48h1v1h-1zM45,48h1v1h-1zM46,48h1v1h-1zM47,48h1v1h-1zM48,48h1v1h-1zM2,49h1v1h-1zM8,49h1v1h-1zM10,49h1v1h-1zM14,49h1v1h-1zM15,49h1v1h-1zM16,49h1v1h-1zM18,49h1v1h-1zM22,49h1v1h-1zM23,49h1v1h-1zM25,49h1v1h-1zM29,49h1v1h-1zM30,49h1v1h-1zM32,49h1v1h-1zM34,49h1v1h-1zM35,49h1v1h-1zM37,49h1v1h-1zM38,49h1v1h-1zM40,49h1v1h-1zM49,49h1v1h-1zM2,50h1v1h-1zM3,50h1v1h-1zM4,50h1v1h-1zM5,50h1v1h-1zM6,50h1v1h-1zM7,50h1v1h-1zM8,50h1v1h-1zM10,50h1v1h-1zM12,50h1v1h-1zM15,50h1v1h-1zM16,50h1v1h-1zM17,50h1v1h-1zM19,50h1v1h-1zM20,50h1v1h-1zM21,50h1v1h-1zM24,50h1v1h-1zM28,50h1v1h-1zM29,50h1v1h-1zM30,50h1v1h-1zM31,50h1v1h-1zM33,50h1v1h-1zM34,50h1v1h-1zM36,50h1v1h-1zM37,50h1v1h-1zM38,50h1v1h-1zM42,50h1v1h-1zM44,50h1v1h-1zM46,50h1v1h-1zM48,50h1v1h-1zM49,50h1v1h-1zM50,50h1v1h-1z"/></svg>';

      var VCARD_PAYLOAD = [
        "BEGIN:VCARD",
        "VERSION:3.0",
        "N:Holcomb;Caleb;TR;;",
        "FN:Caleb Holcomb — TYR Technical Consulting",
        "ORG:TYR Technical Consulting (CALEB TR HOLCOMB d/b/a TYR)",
        "TITLE:IT Systems Engineer & Software Developer",
        "TEL;TYPE=WORK,VOICE,CELL,MSG:+16592578043",
        "EMAIL;TYPE=WORK,PREF,INTERNET:tyr@tyrprotocol.pro",
        "EMAIL;TYPE=HOME,INTERNET:colacal43@gmail.com",
        "URL;TYPE=WORK:https://tyrprotocol.pro",
        "URL;TYPE=GitHub:https://github.com/kalcola",
        "X-SOCIALPROFILE;TYPE=linkedin:https://www.linkedin.com/company/tyrs-technical-consulting",
        "ADR;TYPE=WORK:;;;;AL;;United States",
        "NOTE:Patron Triad Alignment — Tyr (Unyielding Integrity & Telemetry-First Precision) | Freyja (Sovereign Agency & 100% Client Custody) | Loki (Tactical Adaptability & Lean Local-First Engineering). Primary Email: tyr@tyrprotocol.pro | Personal Fallback: colacal43@gmail.com | GitHub: https://github.com/kalcola. NAICS 541512 & 541611.",
        "END:VCARD"
      ].join("\r\n");

      var qrMode = "url";

      function renderAllQrCodes() {
        var targets = document.querySelectorAll(".qr-render-target");
        var captions = document.querySelectorAll(".qr-caption-target");
        var svgHtml = qrMode === "url" ? QR_URL_SVG : QR_VCARD_SVG;
        var capText = qrMode === "url" ? "SCAN: tyrprotocol.pro" : "SCAN: Dual-Email .vcf";

        for (var i = 0; i < targets.length; i++) {
          targets[i].innerHTML = svgHtml;
        }
        for (var j = 0; j < captions.length; j++) {
          captions[j].textContent = capText;
        }
      }

      renderAllQrCodes();

      var qrToggles = document.querySelectorAll(".qr-toggle-trigger");
      for (var q = 0; q < qrToggles.length; q++) {
        qrToggles[q].addEventListener("click", function(e) {
          e.stopPropagation();
          qrMode = qrMode === "url" ? "vcard" : "url";
          renderAllQrCodes();
        });
      }

      var triadContent = {
        front: {
          tyr: {
            cls: "active-tyr",
            border: "border-tyr",
            heading: "ᛏ TYR — UNYIELDING PERSONAL INTEGRITY & TRUTH",
            body: "Grounded in the Spear of Tiw: direct, plainspoken candor, personal accountability, and standing by one's word without compromise or pretense."
          },
          freyja: {
            cls: "active-freyja",
            border: "border-freyja",
            heading: "ᚠ FREYJA — SOVEREIGN BOUNDARIES & NON-COERCIVE AGENCY",
            body: "Fierce independence, self-reliance, and respect for personal privacy—where every interaction is voluntary, transparent, and uncoerced."
          },
          loki: {
            cls: "active-loki",
            border: "border-loki",
            heading: "ᚲ LOKI — TACTICAL ADAPTABILITY WITHOUT DOGMA",
            body: "Relentless curiosity across hardware, Linux/Windows internals, and code—solving complex problems through lateral wit rather than rigid orthodoxy."
          }
        },
        back: {
          tyr: {
            cls: "active-tyr",
            border: "border-tyr",
            heading: "ᛏ TYR QUALITY — ROOT-CAUSE PRECISION & VERIFIABLE RIGOR",
            body: "Telemetry-first diagnostics and deterministic engineering. Every configuration is verified against hard evidence and statutory standards—zero guesswork."
          },
          freyja: {
            cls: "active-freyja",
            border: "border-freyja",
            heading: "ᚠ FREYJA QUALITY — 100% CLIENT CUSTODY & ZERO LOCK-IN",
            body: "Complete administrative sovereignty. Clients own their domains, source code, and records outright—never held hostage by proprietary subscriptions."
          },
          loki: {
            cls: "active-loki",
            border: "border-loki",
            heading: "ᚲ LOKI QUALITY — LEAN, LOCAL-FIRST & RESILIENT EXECUTION",
            body: "Cutting through bloated corporate overhead to engineer fast, self-contained, durable architectures built for real-world reliability."
          }
        }
      };

      function selectDeity(deityKey) {
        var frontInfo = triadContent.front[deityKey];
        var backInfo = triadContent.back[deityKey];
        if (!frontInfo || !backInfo) return;

        var allTabs = document.querySelectorAll(".deity-tab");
        for (var i = 0; i < allTabs.length; i++) {
          var d = allTabs[i].getAttribute("data-deity");
          allTabs[i].className = "deity-tab";
          if (d === deityKey) {
            allTabs[i].classList.add(frontInfo.cls);
            allTabs[i].setAttribute("aria-selected", "true");
          } else {
            allTabs[i].setAttribute("aria-selected", "false");
          }
        }

        var fBox = document.getElementById("front-deity-box");
        var fHead = document.getElementById("front-deity-heading");
        var fBody = document.getElementById("front-deity-body");
        if (fBox && fHead && fBody) {
          fBox.className = "deity-insight-box " + frontInfo.border;
          fHead.textContent = frontInfo.heading;
          fBody.textContent = frontInfo.body;
        }

        var bBox = document.getElementById("back-deity-box");
        var bHead = document.getElementById("back-deity-heading");
        var bBody = document.getElementById("back-deity-body");
        if (bBox && bHead && bBody) {
          bBox.className = "deity-insight-box " + backInfo.border;
          bHead.textContent = backInfo.heading;
          bBody.textContent = backInfo.body;
        }
      }

      var deityTabs = document.querySelectorAll(".deity-tab");
      for (var t = 0; t < deityTabs.length; t++) {
        deityTabs[t].addEventListener("click", function(e) {
          e.stopPropagation();
          selectDeity(this.getAttribute("data-deity"));
        });
      }

      // Resilient Hyperlink Opener for Iframe / Canva / In-App Mobile WebViews
      var directLinks = document.querySelectorAll(".direct-link");
      for (var l = 0; l < directLinks.length; l++) {
        directLinks[l].addEventListener("touchstart", function(e) {
          e.stopPropagation();
        }, { passive: true });
        directLinks[l].addEventListener("click", function(e) {
          e.stopPropagation();
          var targetUrl = this.getAttribute("data-href") || this.getAttribute("href");
          if (!targetUrl) return;
          if (window.self !== window.top && targetUrl.indexOf("http") === 0) {
            e.preventDefault();
            var opened = null;
            try {
              opened = window.open(targetUrl, "_blank", "noopener");
            } catch (err) {}
            if (!opened) {
              try {
                window.top.location.href = targetUrl;
              } catch (err2) {
                window.location.assign(targetUrl);
              }
            }
          }
        });
      }

      // Free-Floating 3D Omni-Directional Physics with Auto-Fit Scale & Active-Face Isolation
      var viewport = document.getElementById("omni-viewport");
      var card3d = document.getElementById("omni-card-3d");
      var frontFace = document.getElementById("omni-face-front");
      var backFace = document.getElementById("omni-face-back");

      var rotX = 4;
      var rotY = -5;
      var fitScale = 1;
      var pointerDown = false;
      var isDragging = false;
      var startX = 0;
      var startY = 0;
      var startRotX = 0;
      var startRotY = 0;

      function computeFitScale() {
        if (!card3d) return;
        var availW = Math.max(240, window.innerWidth - 22);
        var availH = Math.max(220, window.innerHeight - 24);
        var naturalW = card3d.offsetWidth || 340;
        var naturalH = card3d.offsetHeight || 300;
        var sW = availW / naturalW;
        var sH = availH / naturalH;
        fitScale = Math.min(1, sW, sH);
      }

      function applyCardTransform() {
        if (!card3d) return;
        card3d.style.transform =
          "scale(" + fitScale.toFixed(3) + ") rotateX(" + rotX.toFixed(1) + "deg) rotateY(" + rotY.toFixed(1) + "deg)";
        var normY = ((rotY % 360) + 360) % 360;
        var showingBack = (normY > 90 && normY < 270);
        if (frontFace && backFace) {
          frontFace.style.pointerEvents = showingBack ? "none" : "auto";
          backFace.style.pointerEvents = showingBack ? "auto" : "none";
        }

        var radY = (rotY * Math.PI) / 180;
        var radX = (rotX * Math.PI) / 180;
        var gx = 50 + Math.sin(radY) * 40;
        var gy = 46 - Math.sin(radX) * 38;
        var ox2 = 50 - Math.cos(radY) * 34;
        var oy2 = 54 + Math.cos(radX) * 32;
        var oAngle = ((rotY * 2.4 + rotX * 1.8) % 360 + 360) % 360;

        card3d.style.setProperty("--glint-x", Math.round(gx) + "%");
        card3d.style.setProperty("--glint-y", Math.round(gy) + "%");
        card3d.style.setProperty("--oil-x2", Math.round(ox2) + "%");
        card3d.style.setProperty("--oil-y2", Math.round(oy2) + "%");
        card3d.style.setProperty("--oil-angle", Math.round(oAngle) + "deg");
      }

      computeFitScale();
      applyCardTransform();

      window.addEventListener("resize", function() {
        computeFitScale();
        applyCardTransform();
      });

      function isInteractiveTarget(el) {
        if (!el || !el.closest) return false;
        return Boolean(el.closest("a, button"));
      }

      if (viewport && card3d) {
        viewport.addEventListener("mousedown", function(e) {
          if (isInteractiveTarget(e.target)) return;
          pointerDown = true;
          isDragging = false;
          startX = e.clientX;
          startY = e.clientY;
          startRotX = rotX;
          startRotY = rotY;
        });

        window.addEventListener("mousemove", function(e) {
          if (!pointerDown) return;
          var dx = e.clientX - startX;
          var dy = e.clientY - startY;
          if (!isDragging && Math.hypot(dx, dy) > 5) {
            isDragging = true;
            viewport.classList.add("dragging");
            card3d.classList.add("no-transition");
          }
          if (!isDragging) return;
          rotY = startRotY + dx * 0.55;
          rotX = Math.max(-65, Math.min(65, startRotX - dy * 0.45));
          applyCardTransform();
        });

        window.addEventListener("mouseup", function() {
          if (!pointerDown) return;
          pointerDown = false;
          isDragging = false;
          viewport.classList.remove("dragging");
          card3d.classList.remove("no-transition");
        });

        viewport.addEventListener("touchstart", function(e) {
          if (isInteractiveTarget(e.target)) return;
          if (!e.touches || e.touches.length !== 1) return;
          pointerDown = true;
          isDragging = false;
          startX = e.touches[0].clientX;
          startY = e.touches[0].clientY;
          startRotX = rotX;
          startRotY = rotY;
        }, { passive: true });

        window.addEventListener("touchmove", function(e) {
          if (!pointerDown || !e.touches || e.touches.length !== 1) return;
          var dx = e.touches[0].clientX - startX;
          var dy = e.touches[0].clientY - startY;
          if (!isDragging && Math.hypot(dx, dy) > 6) {
            isDragging = true;
            card3d.classList.add("no-transition");
          }
          if (!isDragging) return;
          rotY = startRotY + dx * 0.65;
          rotX = Math.max(-65, Math.min(65, startRotX - dy * 0.5));
          applyCardTransform();
        }, { passive: true });

        window.addEventListener("touchend", function() {
          if (!pointerDown) return;
          pointerDown = false;
          isDragging = false;
          card3d.classList.remove("no-transition");
        });

        viewport.addEventListener("dblclick", function(e) {
          if (isInteractiveTarget(e.target)) return;
          var normY = ((rotY % 360) + 360) % 360;
          var isBack = (normY > 90 && normY < 270);
          rotX = 4;
          rotY = isBack ? 0 : 180;
          applyCardTransform();
        });
      }

      var flipBtns = document.querySelectorAll(".flip-card-trigger");
      for (var f = 0; f < flipBtns.length; f++) {
        flipBtns[f].addEventListener("click", function(e) {
          e.stopPropagation();
          var normY = ((rotY % 360) + 360) % 360;
          var isBack = (normY > 90 && normY < 270);
          rotX = 4;
          rotY = isBack ? 0 : 180;
          applyCardTransform();
        });
      }

      var vcfTriggers = document.querySelectorAll(".download-vcf-trigger");
      for (var v = 0; v < vcfTriggers.length; v++) {
        vcfTriggers[v].addEventListener("click", function(e) {
          e.stopPropagation();
          var blob = new Blob([VCARD_PAYLOAD], { type: "text/vcard;charset=utf-8" });
          var url = URL.createObjectURL(blob);
          var a = document.createElement("a");
          a.href = url;
          a.download = "TYR_Caleb_Holcomb.vcf";
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          setTimeout(function() { URL.revokeObjectURL(url); }, 1500);
        });
      }
    })();
