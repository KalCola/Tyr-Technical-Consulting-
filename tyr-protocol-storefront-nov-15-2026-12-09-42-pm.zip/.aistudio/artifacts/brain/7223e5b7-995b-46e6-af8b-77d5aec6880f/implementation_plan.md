# Unified Nine Realms Obsidian 3D Card & Personal/Business Storefront

Unify the live `tyrprotocol.pro` web storefront, standalone 3D business card, and native Android app around the **Nine Realms Obsidian color scheme, glowing realm border highlights, and 3-column attribute strip layout**, bridging both **Personal** and **Business** modes in one cohesive two-sided experience.

### User Review & Critical Decisions

> [!IMPORTANT]
> All four architectural and visual choices below were confirmed during discovery and lock the design direction across both platforms:
> - **Visual Base (Confirmed):** Nine Realms Obsidian (`#060609` void / `#0C0D13` surface / `#11131A` card / `#090A0F` attribute wells) with glowing realm border highlights (Midgard Crimson `#DC2626`, Asgard Gold `#FBBF24`, Vanaheim Emerald `#34D399`).
> - **Personal + Business Compromise (Confirmed):** Two-sided **Personal (Front) / Business (Back)** 3D interactive card paired with a persistent **Personal / Business Storefront Toggle** across the main header and navigation.
> - **Target Platforms (Confirmed):** Both the live `tyrprotocol.pro` GitHub Pages storefront (including its embedded/standalone 3D card) and the native Android Jetpack Compose app.
> - **Anchoring Card Details (Confirmed):** Interactive **Patron Triad** attributes (`ᛏ Týr`, `ᚠ Freyja`, `ᚲ Loki`), tap-to-toggle **Scannable QR Code** (`tyrprotocol.pro` URL ↔ offline `.vcf` vCard), one-tap `.vcf` contact save/download, and direct communication channels (`tel`, `sms`, dual `mailto`, GitHub, LinkedIn).

---

### 1. Overview & Core Concept

- **What It Does:** Delivers a seamless dual-identity showcase where prospects, local neighbors, and B2B procurement leads experience the exact same **Nine Realms Obsidian** aesthetic whether they land on the 3D business card, browse the storefront catalog, or use the Android app. A single **Personal ↔ Business** toggle synchronizes the 3D card face, active header framing, and catalog emphasis without fragmenting navigation or theme tokens.
- **Target Audience / Persona:**
  - *Personal / Direct Contacts:* Community contacts, peers, and local Northwest Alabama referrals scanning the card for Caleb Holcomb's personal alignment, GitHub profile, direct phone/personal email fallback, and `.vcf` contact download.
  - *Business / Commercial Clients:* Small-business owners and remote B2B leads evaluating TYR Technical Consulting (`NAICS 541512 & 541611`, `CALEB TR HOLCOMB d/b/a TYR`), Patron Triad service standards, and flat-rate / retainer SKUs.
- **Key Value:** Eliminates the jarring visual split between a neon pastel 3D card and the dark Obsidian storefront while preserving the tactile 3D two-sided Personal/Business compromise from the Android app.

---

### 2. User Experience & Visual Design

- **Key User Flows:**
  1. **Unified Mode Toggle (`Personal` ↔ `Business`):** Tapping the mode switcher in the top header flips the active identity posture—switching the embedded 3D card to the matching face (`Front: Personal` or `Back: Business`) and highlighting corresponding Personal vs. Business attributes and pricing tiers across the storefront.
  2. **Embedded & Standalone 3D Two-Sided Card:** Users can inspect the 3D card directly on the storefront landing/card tab (`P0` on Web, Tab `0` on Android) or open the standalone card URL. Dragging tilts the card in 3D with a subtle crimson/gold specular glint; double-tapping or clicking **Flip 180°** rotates cleanly between the **Personal Front** and **Business Back**.
  3. **Interactive Patron Triad Attributes:** Tapping `ᛏ Týr`, `ᚠ Freyja`, or `ᚲ Loki` updates both the glowing realm border highlight and the **3-column attribute strip** (`Pillar`, `Guarantee`, `Focus` / `Alignment`) plus the insight callout box tailored to whichever side (Personal or Business) is facing forward.
  4. **Scannable Dual-Mode QR Toggle & Instant Channels:** Tapping the QR badge toggles between a scannable **Storefront URL QR** (`https://tyrprotocol.pro` or `https://tyrprotocol.pro?mode=...`) and an **Offline Dual-Email vCard QR**, accompanied by one-tap `.vcf` save/download, native share, SMS handshake, dual email (`tyr@tyrprotocol.pro` & personal fallback), GitHub, and LinkedIn actions.

- **Visual Identity & Theme:**
  - *Aesthetic Direction:* Dark forged obsidian glass-and-steel dossier with crisp realm-coded neon edge luminance (restraint and high contrast over multi-hue rainbow gradients).
  - *Color Palette & Mood:*
    - **Void & Surfaces:** Void Obsidian (`#060609`), Elevated Surface (`#0C0D13`), Card Surface (`#11131A`), Attribute Well (`#090A0F`), Steel Border (`#232634`).
    - **Personal Front Glow Tokens:** Anchored by **Týr / Midgard Crimson** (`#DC2626` / `#F87171`) paired with **Teiwaz Gold** (`#FBBF24`) specular edge glow (`box-shadow` halo on hover/active face).
    - **Business Back Glow Tokens:** Anchored by **Asgard Gold** (`#D97706` / `#FBBF24`) paired with **Vanaheim Emerald** (`#059669` / `#34D399`) operational readiness indicators.
    - **Triad Tab Highlights:** `Týr` (`#DC2626`), `Freyja` (`#FBBF24`), `Loki` (`#E11D48` / `#34D399` tactical accent).
  - *Typography & Hierarchy:* Clean geometric sans-serif display headers (`16sp–20sp` bold) paired with crisp `11sp–13sp` body copy and uppercase `9sp–10sp` monospace (`ui-monospace`) tags for SKUs, NAICS/EIN metadata, and attribute strip labels.
  - *Component Styling & Layout:*
    - Matches the signature **3-column Attribute Strip** (`#090A0F` container, `1px` `#232634` hairline, uppercase muted label above crisp white value) on both sides of the 3D card AND across catalog service cards.
    - Consistent `16dp` / `16px` rounded corners, glowing `1.5dp` realm-tinted borders, and `48dp` minimum touch targets on mobile Android Compose controls (`minimumInteractiveComponentSize()`), respecting `WindowInsets.navigationBars` and `safeDrawing`.

- **Interactive Feedback & Motion:**
  - Smooth spring/cubic-bezier 3D flip (`550ms`) with pointer-tracked specular light glint; Android Compose `animateFloatAsState` flip + `graphicsLayer` 3D perspective (`cameraDistance`).
  - Auto-fading 3-second gesture hint badge (`Drag to rotate • Double-tap to flip`) that dismisses immediately on interaction.
  - Instant visual pill confirmation (`✓ Copied`, `SCAN: tyrprotocol.pro` ↔ `SCAN: Dual-Email .vcf`, active mode glow pulse) when toggling QR codes or copying links.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Unify Under Nine Realms Obsidian Instead of Separate Dual-Aura Palettes**
  - *Chosen Approach:* Replace the violet/pink/cyan pastel aura on the standalone 3D card with the exact Nine Realms Obsidian palette, glowing realm borders (Crimson/Gold/Emerald), and 3-column Attribute Strips used across the main storefront.
  - *Why:* Eliminates visual whiplash when moving between the 3D card and service catalog while fulfilling the exact user preference to keep the storefront's color scheme and attributes layout across both Personal and Business modes.
  - *Alternatives Considered:* Keeping the neon violet/cyan card untouched and adding a second theme switch—rejected because maintaining two clashing color systems fragments brand recall and complicates component parity.

- **Decision 2: True Scannable QR Matrix Toggle (`URL` ↔ `.vcf`) in Both Web & Android Card Faces**
  - *Chosen Approach:* Reuse the deterministic pure-client ISO/IEC 18004 QR encoders already built for the Growth Hub on both Web and Android so the 3D card's QR badge renders real scannable camera codes in both `tyrprotocol.pro` URL mode and offline `.vcf` vCard mode.
  - *Why:* Replaces the hash-seeded placeholder grid previously inside the native Android card with a real scannable QR matrix, making physical screen-to-phone scanning reliable offline.
  - *Alternatives Considered:* Showing two static side-by-side QR boxes or a third-party QR CDN—rejected to preserve a compact single QR dock with tap-to-toggle feedback and strict zero-external-network OPSEC.

- **Decision 3: Synchronized Personal / Business Storefront Toggle**
  - *Chosen Approach:* Add a segmented `Personal` / `Business` / `All` mode pill in the top header and quick navigation on both Web and Android. Switching to `Personal` flips the 3D card to the Front (Personal) face and emphasizes solo/personal service attributes (e.g., Personal tier rates, offline privacy, direct personal contact); switching to `Business` flips the card to the Back (Business) face and emphasizes Business/B2B rates, NAICS/EIN verification, and consulting workflows.
  - *Why:* Honors "compromise and have both a personal and a business like the one you have in app, keeping this one's color and theme" at both the identity-card level and the storefront browsing level.
  - *Alternatives Considered:* Splitting Personal and Business into two disconnected websites—rejected to keep domain authority, SEO, and user discovery consolidated at `tyrprotocol.pro`.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram:**

```
┌──────────────────────────────────────────────────────────────────────┐
│                   SHARED IDENTITY & MODE STATE                       │
│   activeMode: PERSONAL | BUSINESS    activeDeity: TYR | FREYJA | LOKI│
│   qrMode: URL | VCARD                selectedSku / activePage        │
└───────────────────────────────┬──────────────────────────────────────┘
                                │
         ┌──────────────────────┴──────────────────────┐
         ▼                                             ▼
┌─────────────────────────────────┐   ┌────────────────────────────────┐
│   WEB STOREFRONT & 3D CARD      │   │   NATIVE ANDROID COMPOSE APP   │
│                                 │   │                                │
│ ┌─────────────────────────────┐ │   │ ┌────────────────────────────┐ │
│ │ Header Mode Toggle Pill     │ │   │ │ Top App Bar Mode Switcher  │ │
│ │ [Personal] <-> [Business]   │ │   │ │ [Personal] <-> [Business]  │ │
│ └──────────────┬──────────────┘ │   │ └─────────────┬──────────────┘ │
│                ▼                │   │               ▼                │
│ ┌─────────────────────────────┐ │   │ ┌────────────────────────────┐ │
│ │ P0 Embedded 3D Card Stage   │ │   │ │ OmniBusinessCard (Tab 0)   │ │
│ │ + Standalone Card Page      │ │   │ │ • Front: Personal Triad    │ │
│ │ • 3-Col Attribute Strip     │ │   │ │ • Back: Business & Channels│ │
│ │ • Realm Glowing Borders     │ │   │ │ • Canvas ISO QR Toggle     │ │
│ │ • SVG/Matrix QR Toggle      │ │   │ │ • Native Contacts / Share  │ │
│ └──────────────┬──────────────┘ │   │ └─────────────┬──────────────┘ │
│                ▼                │   │               ▼                │
│ ┌─────────────────────────────┐ │   │ ┌────────────────────────────┐ │
│ │ Catalog & Service Deck      │ │   │ │ Nine Realms Service Cards  │ │
│ │ Highlights Personal vs Biz  │ │   │ │ Emphasizes Personal vs Biz │ │
│ │ Tier Attributes & Quick CTA │ │   │ │ Tier Attributes & Checkout │ │
│ └─────────────────────────────┘ │   │ └────────────────────────────┘ │
└─────────────────────────────────┘   └────────────────────────────────┘
```

- **Data Model & State:**
  - **Identity & Triad Profiles:** Structured Personal (`Front`) and Business (`Back`) data objects containing display role, 3-column **Attribute Strip** entries (changing dynamically per selected deity `Týr` / `Freyja` / `Loki`), glow accent tokens, vCard 3.0 dual-email payload, and verified channel URIs (Phone, SMS, Work Email, Personal Email, GitHub, LinkedIn, Storefront URL).
  - **Storefront Mode Preference:** Client-persisted active identity posture (`PERSONAL` or `BUSINESS`, defaulting cleanly and toggled live from header controls or card flips).
  - **Service Tier Emphasis:** Existing dual-priced and solo/B2B service entries leverage the active storefront mode to bubble relevant tier attributes (e.g., Personal Tier vs. Business Tier pricing and compliance badges) cleanly to the top without hiding core capabilities.

- **Interactive Component & State Mapping:**
  - **Header Mode Toggle (`Personal` ↔ `Business`):** Updates global storefront posture, flips the active 3D card face (`0deg` Front vs `180deg` Back), updates header badge accent glow (Crimson/Gold vs Gold/Emerald), and highlights matching Personal or Business tier attributes in the catalog.
  - **3D Card Drag & Flip Gesture Handler:** Tracks pointer drag deltas to compute clamped X/Y perspective rotation (`±65°` pitch, continuous yaw) plus dynamic specular glint; double-tap or Flip button resets tilt and smoothly animates `180°` face flip while syncing the active storefront mode pill.
  - **Patron Triad Selector (`ᛏ Týr`, `ᚠ Freyja`, `ᚲ Loki`):** Mutates `activeDeity`, swapping the glowing card edge highlight (`Crimson` / `Gold` / `Emerald-Rose`), updating the 3-column **Attribute Strip** cells, and refreshing the Triad pledge/deliverable insight box for the active side.
  - **QR Mode Dock (`URL` ↔ `.vcf`):** Toggles between rendering the scannable `https://tyrprotocol.pro` QR matrix and the compact dual-email vCard QR matrix inside the card dock, paired with one-tap `.vcf` file export / Android Contacts insert fallback and Web Share / Android Share Sheet dispatch.
